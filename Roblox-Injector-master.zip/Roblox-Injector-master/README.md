# Roblox-Injector
A simple lua injector made specifically for roblox. (Windows Only)
After you Start Roblox up press the attach button. It shoul then give you a message saying "dll injected!"
Then you can write your lua script and press execute.
Clear will empty the text box.
Admin is a pre programmed script that gives you access to the infinite yeild admin gui. It will automatically update the infinite yield script.

When you download this it will say it is a hacktool or sometimes windows defender calls it a trojan horse. This is a false positive becausse of the dll file i used. You havee to allow it on your system. This injector is unstable and will sometimes crash your roblox game, sorry.
